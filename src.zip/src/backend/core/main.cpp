#include <stdlib.h>
#include <stdio.h>
#include <GL/glfw.h>
#include <emscripten/emscripten.h>
#include "src/backend/engine/maths.h"
#include "src/backend/engine/texture.h"
#include "src/backend/engine/shaders.h"
#include "src/backend/engine/render.h"

int initialize();
void mainloop();

//globals for now just for testing
//look in defines.h if you want to see what this "global" type is
global OrthoShader ortho;
global StaticShader basic;
global Texture tex;
global Model cube;
global mat4 transform;
global Camera camera;
global Mesh mesh;
global GLuint vertexPosObject;

global bool initialized = false;

std::string staircaseobjhardcoded = R"foo(
# Blender v2.81 (sub 16) OBJ File: 'brickStairs.blend'
# www.blender.org
o Cube
v 1.000000 -0.305904 -1.000000
v 1.000000 -1.000000 -1.000000
v 1.000000 0.004291 1.000000
v 1.000000 -1.000000 1.000000
v -1.000000 -0.305904 -1.000000
v -1.000000 -1.000000 -1.000000
v -1.000000 0.004291 1.000000
v -1.000000 -1.000000 1.000000
v -1.000000 -1.000000 -0.333333
v -1.000000 -1.000000 0.333333
v 1.000000 -0.305904 -0.333333
v 1.000000 0.004291 0.333333
v -1.000000 0.004291 0.333333
v -1.000000 -0.305904 -0.333333
v 1.000000 -1.000000 0.333333
v 1.000000 -1.000000 -0.333333
v 1.000000 1.007030 1.000000
v -1.000000 1.007030 1.000000
v 1.000000 1.007030 0.333333
v -1.000000 1.007030 0.333333
v 1.000000 0.373047 -0.333333
v 1.000000 0.373047 0.333333
v -1.000000 0.373047 0.333333
v -1.000000 0.373047 -0.333333
vt 0.343250 0.501045
vt 0.005073 0.501045
vt 0.005073 0.338979
vt 0.343250 0.338979
vt 0.005073 0.663361
vt 0.343250 0.663361
vt 0.578847 0.329248
vt 0.578847 0.217066
vt 0.691572 0.217066
vt 0.691572 0.329248
vt 0.578847 0.662208
vt 0.578847 0.338962
vt 0.691572 0.338962
vt 0.691572 0.662208
vt 0.230524 0.329248
vt 0.230524 0.166931
vt 0.343250 0.166931
vt 0.343250 0.329248
vt 0.815769 0.662208
vt 0.698406 0.662208
vt 0.698406 0.338962
vt 0.815769 0.338962
vt 0.005073 0.329248
vt 0.005073 0.217066
vt 0.117798 0.217066
vt 0.117798 0.329248
vt 0.353395 0.662208
vt 0.353395 0.338962
vt 0.466121 0.338962
vt 0.466121 0.662208
vt 0.353395 0.329248
vt 0.353395 0.166931
vt 0.466121 0.166931
vt 0.466121 0.329248
vt 0.462739 0.671905
vt 0.462739 0.995151
vt 0.350013 0.995151
vt 0.350013 0.671906
vt 0.466121 0.107332
vt 0.578847 0.107332
vt 0.985700 0.004849
vt 0.985700 0.328094
vt 0.872974 0.328094
vt 0.872974 0.004849
vt 0.230524 0.004866
vt 0.343250 0.004866
vt 0.353395 0.004866
vt 0.466121 0.004866
vt 0.868740 0.004849
vt 0.868740 0.328095
vt 0.699188 0.328095
vt 0.699188 0.004849
vt 0.578847 0.671905
vt 0.578847 0.995151
vt 0.466121 0.995151
vt 0.466121 0.671905
vt 0.117798 0.107332
vt 0.230524 0.107332
vt 0.934055 0.338962
vt 0.934055 0.662208
vt 0.819252 0.662208
vt 0.819252 0.338962
vt 0.936712 0.662208
vt 0.936712 0.338962
vt 0.999065 0.338962
vt 0.999065 0.662208
vn 0.0000 0.0000 1.0000
vn -1.0000 0.0000 0.0000
vn 0.0000 -1.0000 0.0000
vn 1.0000 0.0000 0.0000
vn 0.0000 0.0000 -1.0000
vn 0.0000 1.0000 0.0000
s off
f 7/1/1 3/2/1 17/3/1 18/4/1
f 4/5/1 3/2/1 7/1/1 8/6/1
f 9/7/2 14/8/2 5/9/2 6/10/2
f 10/11/3 15/12/3 4/13/3 8/14/3
f 15/15/4 12/16/4 3/17/4 4/18/4
f 6/19/5 5/20/5 1/21/5 2/22/5
f 2/23/4 1/24/4 11/25/4 16/26/4
f 16/26/4 11/25/4 12/16/4 15/15/4
f 6/27/3 2/28/3 16/29/3 9/30/3
f 9/30/3 16/29/3 15/12/3 10/11/3
f 8/31/2 7/32/2 13/33/2 10/34/2
f 10/34/2 13/33/2 14/8/2 9/7/2
f 1/35/6 5/36/6 14/37/6 11/38/6
f 14/8/2 13/33/2 23/39/2 24/40/2
f 19/41/6 20/42/6 18/43/6 17/44/6
f 3/17/4 12/16/4 19/45/4 17/46/4
f 13/33/2 7/32/2 18/47/2 20/48/2
f 12/49/5 13/50/5 20/51/5 19/52/5
f 21/53/6 24/54/6 23/55/6 22/56/6
f 12/16/4 11/25/4 21/57/4 22/58/4
f 11/59/5 14/60/5 24/61/5 21/62/5
f 13/63/1 12/64/1 22/65/1 23/66/1
)foo";

//Cube Mesh Data (just a shit ton of 3d points in space to define all the triangles that make up the cube, I found it on google)
//once we have the .obj loader working then we will just load models instead of hardcoding them.
static const GLfloat g_vertex_buffer_data[] = {
    -1.0f,-1.0f,-1.0f, // triangle 1 : begin
    -1.0f,-1.0f, 1.0f,
    -1.0f, 1.0f, 1.0f, // triangle 1 : end
    1.0f, 1.0f,-1.0f, // triangle 2 : begin
    -1.0f,-1.0f,-1.0f,
    -1.0f, 1.0f,-1.0f, // triangle 2 : end
    1.0f,-1.0f, 1.0f,
    -1.0f,-1.0f,-1.0f,
    1.0f,-1.0f,-1.0f,
    1.0f, 1.0f,-1.0f,
    1.0f,-1.0f,-1.0f,
    -1.0f,-1.0f,-1.0f,
    -1.0f,-1.0f,-1.0f,
    -1.0f, 1.0f, 1.0f,
    -1.0f, 1.0f,-1.0f,
    1.0f,-1.0f, 1.0f,
    -1.0f,-1.0f, 1.0f,
    -1.0f,-1.0f,-1.0f,
    -1.0f, 1.0f, 1.0f,
    -1.0f,-1.0f, 1.0f,
    1.0f,-1.0f, 1.0f,
    1.0f, 1.0f, 1.0f,
    1.0f,-1.0f,-1.0f,
    1.0f, 1.0f,-1.0f,
    1.0f,-1.0f,-1.0f,
    1.0f, 1.0f, 1.0f,
    1.0f,-1.0f, 1.0f,
    1.0f, 1.0f, 1.0f,
    1.0f, 1.0f,-1.0f,
    -1.0f, 1.0f,-1.0f,
    1.0f, 1.0f, 1.0f,
    -1.0f, 1.0f,-1.0f,
    -1.0f, 1.0f, 1.0f,
    1.0f, 1.0f, 1.0f,
    -1.0f, 1.0f, 1.0f,
    1.0f,-1.0f, 1.0f
};

void test() {
	printf("This was printed from a C++ function, called from a C function.\n");
}

extern "C" {
	
	int print_hello(int x) {
		printf("Hello emscripten! This is my parameter: %d\n", x);
		test();
		return x;
	}
	
	bool is_ready() {
		return initialized;
	}
	
}

int main(void) 
{
	if (initialize() == GL_TRUE) {		
		glClearColor(0.1f, 0.1f, 0.2f, 0.0f);
		
		ortho.load();
		basic.load();        
		basic.set_shadows_on(false);
		camera = {0};
		
		initialized = true;
        printf("Obj: %s\n",staircaseobjhardcoded.c_str());
        cube = load_model_string(staircaseobjhardcoded);

		emscripten_set_main_loop(mainloop, 0, 1);

		//tex = load_texture("data/textures/lava.png", GL_LINEAR);
		cube = load_model("data/models/cube.obj");

	}
		
	glfwTerminate();

	return 0;
}

int initialize()
{
	const int width = 1000,
	         height = 640;

	if (glfwInit() != GL_TRUE) {
		printf("glfwInit() failed\n");
		return GL_FALSE;
	}
	//set webgl context settings
	glfwOpenWindowHint(GLFW_OPENGL_VERSION_MAJOR, 3);
    glfwOpenWindowHint(GLFW_OPENGL_VERSION_MINOR, 3);
	glfwOpenWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	//enable anti-aliasing
	glfwOpenWindowHint(GLFW_FSAA_SAMPLES, 4);
	
	if (glfwOpenWindow(width, height, 8, 8, 8, 8, 16, 0, GLFW_WINDOW) != GL_TRUE) {
		printf("glfwOpenWindow() failed\n");
    	return GL_FALSE;
    }
	
    glfwSwapInterval(1);
	
	printf("|||||||||||||||||||||||||||||||||\n");
	printf("|  Gaffney Orthotics Capstone   |\n");
	printf("|||||||||||||||||||||||||||||||||\n");
	printf("\n");
	
	printf("OpenGL Version: %s\n", glGetString(GL_VERSION));
	printf("GLSL Version:   %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));
	printf("OpenGL Vendor:  %s\n", glGetString(GL_VENDOR));
	glEnable(GL_MULTISAMPLE);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	glfwSetWindowTitle("Gaffney Orthotics");
	
	//load the cube vertex data into it's buffer
	glGenBuffers(1, &mesh.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(g_vertex_buffer_data), g_vertex_buffer_data, GL_STATIC_DRAW);
	
	//load the triangle vertex data into it's buffer
	GLfloat vVertices[] = {  0.0f,  0.5f, 0.0f, 
                           -0.5f, -0.5f, 0.0f,
                            0.5f, -0.5f, 0.0f };

    glGenBuffers(1, &vertexPosObject);
    glBindBuffer(GL_ARRAY_BUFFER, vertexPosObject);
    glBufferData(GL_ARRAY_BUFFER, 9*4, vVertices, GL_STATIC_DRAW);

    return GL_TRUE;
}

void mainloop()
{	
	//clear the screen of anything that might have been on there last frame
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	//set the viewport to the same as the windows resolution (feel free to mess around with the numbers if you want to see what it does)
	glViewport(0, 0, 1000, 640);
	
	local float rotation = 0.0f;
	rotation+=0.2f;
	//create a transformation matrix to transform the cube vertices from model space to world space (translate it by x,y,z, rotate it by rotX,rotY,rotZ, scale by scaleX,scaleY,scaleZ)
	transform = create_transformation_matrix( {-2, 0, 0}, {rotation, rotation, rotation}, {1, 1, 1} );
	
	local float zoom = 15.0f;
	zoom -= 0.025f;
	
	//bind the shader to prepare it for rendering
	basic.bind();
	//set the model transform to the transform we created.
	basic.set_transform(transform);
	//set the view matrix (the matrix that defines how the camera is viewing the world) to look at (0, 0, 0) from a position of (zoom, zoom, zoom)
	basic.set_view(look_at({zoom, zoom, zoom}, {0, 0, 0}));
	
	//Prepare cube mesh for rendering (bind the buffer storing the mesh data, vertices)
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
	//then activate that buffers attributes
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (const GLvoid*)0);
    glEnableVertexAttribArray(0);

	//call the rendering (this runs the shader program on the GPU)
    glDrawArrays(GL_TRIANGLES, 0, 12*3); 

    transform = create_transformation_matrix( {2, 0, 0}, {rotation, rotation, rotation}, {2, 2, 2} );
    basic.set_transform(transform);

    //Prepare triangle mesh for rendering (bind the buffer storing the mesh data, vertices)
    glBindBuffer(GL_ARRAY_BUFFER, vertexPosObject);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (const GLvoid*)0);
    glEnableVertexAttribArray(0);

    glDrawArrays ( GL_TRIANGLES, 0, 3 );
 
    glfwSwapBuffers();
    glfwPollEvents();
}